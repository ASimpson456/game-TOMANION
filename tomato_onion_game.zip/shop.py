"""Магазин аксессуаров для героев."""

ITEM_PRICE = 500

SHOP_ITEMS = [
    {
        "id": "tomato_hat",
        "hero": "tomato",
        "name": "Шляпа",
        "desc": "Стильная шляпа для Томата",
    },
    {
        "id": "tomato_sword",
        "hero": "tomato",
        "name": "Меч",
        "desc": "Декоративный меч для Томата",
    },
    {
        "id": "onion_hat",
        "hero": "onion",
        "name": "Шляпа",
        "desc": "Милая шляпа для Лука",
    },
    {
        "id": "onion_bow",
        "hero": "onion",
        "name": "Лук",
        "desc": "Декоративный лук для Лука",
    },
]


def item_by_id(item_id):
    for item in SHOP_ITEMS:
        if item["id"] == item_id:
            return item
    return None
