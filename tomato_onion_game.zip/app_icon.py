"""Иконка TOMANION — томат для окна и exe."""

from pathlib import Path

import pygame

import pixel_art as art

ICON_SIZES = (16, 32, 48, 64, 128, 256)
_cache = {}


def render_tomato_icon(size):
    surf = pygame.Surface((size, size), pygame.SRCALPHA)
    tomato = art._build_tomato()
    tw, th = tomato.get_size()
    scale = min((size * 0.84) / tw, (size * 0.84) / th)
    sw = max(1, int(tw * scale))
    sh = max(1, int(th * scale))
    scaled = pygame.transform.scale(tomato, (sw, sh))
    surf.blit(scaled, ((size - sw) // 2, (size - sh) // 2 - max(1, size // 18)))
    return surf


def get_icon_surface(size=32):
    if size not in _cache:
        if not pygame.get_init():
            pygame.init()
        _cache[size] = render_tomato_icon(size)
    return _cache[size]


def apply_window_icon():
    if not pygame.get_init():
        return
    try:
        pygame.display.set_icon(get_icon_surface(32))
    except pygame.error:
        pass


def write_icon_files(assets_dir=None):
    from PIL import Image

    assets_dir = Path(assets_dir or Path(__file__).parent / "assets")
    assets_dir.mkdir(parents=True, exist_ok=True)
    if not pygame.get_init():
        pygame.init()

    images = []
    for size in ICON_SIZES:
        surf = render_tomato_icon(size)
        img = Image.frombytes("RGBA", (size, size), pygame.image.tostring(surf, "RGBA"))
        images.append(img)

    ico_path = assets_dir / "tomato.ico"
    images[0].save(
        ico_path,
        format="ICO",
        sizes=[(img.width, img.height) for img in images],
        append_images=images[1:],
    )
    images[-1].save(assets_dir / "tomato_icon.png")
    return ico_path
