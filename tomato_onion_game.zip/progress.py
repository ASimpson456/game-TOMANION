import json

from paths import app_dir

PROGRESS_PATH = app_dir() / "progress.json"


def _load_data():
    if PROGRESS_PATH.exists():
        try:
            return json.loads(PROGRESS_PATH.read_text(encoding="utf-8"))
        except (json.JSONDecodeError, OSError):
            pass
    return {}


def _save_data(data):
    try:
        PROGRESS_PATH.write_text(
            json.dumps(data, ensure_ascii=False, indent=2),
            encoding="utf-8",
        )
    except OSError:
        pass


def load_progress():
    data = _load_data()
    return max(1, min(30, int(data.get("max_unlocked", 1))))


def load_current_level():
    data = _load_data()
    max_unlocked = max(1, min(30, int(data.get("max_unlocked", 1))))
    current = int(data.get("current_level", 1))
    return max(1, min(max_unlocked, current))


def save_progress(max_unlocked):
    data = _load_data()
    data["max_unlocked"] = max(1, min(30, max_unlocked))
    _save_data(data)


def save_current_level(level):
    data = _load_data()
    level = max(1, min(30, level))
    data["current_level"] = level
    data["max_unlocked"] = max(data.get("max_unlocked", 1), level)
    _save_data(data)


def unlock_level(completed_level):
    data = _load_data()
    data["max_unlocked"] = max(
        data.get("max_unlocked", 1),
        min(30, completed_level + 1),
    )
    _save_data(data)


def reset_levels():
    data = _load_data()
    data["max_unlocked"] = 1
    data["current_level"] = 1
    _save_data(data)


def load_coins():
    return max(0, int(_load_data().get("coins", 0)))


def save_coins(amount):
    data = _load_data()
    data["coins"] = max(0, int(amount))
    _save_data(data)


def add_coins(delta):
    data = _load_data()
    data["coins"] = max(0, int(data.get("coins", 0)) + int(delta))
    _save_data(data)
    return data["coins"]


def load_owned():
    return list(_load_data().get("owned", []))


def load_equipped():
    default = {"tomato": None, "onion": None}
    equipped = _load_data().get("equipped", {})
    return {**default, **equipped}


def purchase_item(item_id, price):
    data = _load_data()
    owned = list(data.get("owned", []))
    if item_id in owned:
        return "owned"
    coins = int(data.get("coins", 0))
    if coins < price:
        return "nomoney"
    data["coins"] = coins - price
    owned.append(item_id)
    data["owned"] = owned
    _save_data(data)
    return "ok"


def equip_item(hero, item_id):
    data = _load_data()
    owned = list(data.get("owned", []))
    equipped = data.get("equipped", {"tomato": None, "onion": None})
    if item_id is not None:
        if item_id not in owned:
            return False
        item_hero = hero
        for candidate in ("tomato", "onion"):
            if item_id.startswith(candidate + "_"):
                item_hero = candidate
                break
        if item_hero != hero:
            return False
    equipped[hero] = item_id
    data["equipped"] = equipped
    _save_data(data)
    return True


def toggle_equip(item_id, hero):
    equipped = load_equipped()
    if equipped.get(hero) == item_id:
        return equip_item(hero, None)
    return equip_item(hero, item_id)
