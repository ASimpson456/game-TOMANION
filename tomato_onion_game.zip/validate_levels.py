"""Smoke-test: all levels build and pass basic sanity checks."""

from constants import HEIGHT, LEVELS_TOTAL, WIDTH
from levels import LEVEL_INFO, build_level


def check_level(n):
    data = build_level(n)
    issues = []
    world_w = data["world_w"]

    required = (
        "title",
        "hint",
        "solids",
        "goal",
        "tomato",
        "enemies",
        "world_w",
    )
    for key in required:
        if key not in data:
            issues.append(f"missing key: {key}")

    if data["tomato"].rect.right > world_w:
        issues.append("tomato spawn outside world")
    if data["tomato"].rect.bottom > HEIGHT:
        issues.append("tomato spawn below floor")

    goal = data["goal"]
    if goal.rect.right > world_w - 12:
        issues.append("goal outside world bounds")
    if goal.rect.bottom > HEIGHT:
        issues.append("goal below floor")

    if data["onion"] and data["onion"].rect.right > world_w:
        issues.append("onion spawn outside world")

    if data["boss"] and not data["boss"].alive:
        issues.append("boss not alive at start")

    for i, enemy in enumerate(data["enemies"]):
        if not enemy.alive:
            issues.append(f"enemy {i} dead at start")
        if enemy.rect.bottom > HEIGHT + 4:
            issues.append(f"enemy {i} below floor")
        x_min = getattr(enemy, "x_min", None)
        x_max = getattr(enemy, "x_max", None)
        if x_min is not None and x_max is not None and x_min >= x_max:
            issues.append(f"enemy {i} invalid patrol range ({x_min}..{x_max})")
        x1 = getattr(enemy, "x1", None)
        x2 = getattr(enemy, "x2", None)
        if x1 is not None and x2 is not None and x1 >= x2:
            issues.append(f"enemy {i} invalid donut patrol ({x1}..{x2})")

    info = next(x for x in LEVEL_INFO if x["num"] == n)
    if info["boss"] and not data["boss"]:
        issues.append("expected boss missing")
    if info["solo"] and data["coop"]:
        issues.append("solo level marked as coop")

    return data, issues


def main():
    failed = []
    summary = []
    for n in range(1, LEVELS_TOTAL + 1):
        try:
            data, issues = check_level(n)
        except Exception as exc:
            failed.append((n, [f"build error: {exc}"]))
            continue
        if issues:
            failed.append((n, issues))
        summary.append(
            (
                n,
                data["title"],
                len(data["enemies"]),
                data["boss"].name if data["boss"] else "-",
                data["world_w"],
            )
        )

    print(f"Checked {LEVELS_TOTAL} levels\n")
    for n, title, enemies, boss, world_w in summary:
        mark = "OK" if not any(f[0] == n for f in failed) else "FAIL"
        safe_title = title.encode("ascii", "replace").decode("ascii")
        safe_boss = boss.encode("ascii", "replace").decode("ascii")
        print(f"[{mark}] {n:2d} | enemies={enemies:2d} | boss={safe_boss:24s} | W={world_w} | {safe_title}")

    if failed:
        print("\nProblems:")
        for n, issues in failed:
            print(f"  Level {n}:")
            for issue in issues:
                print(f"    - {issue}")
        raise SystemExit(1)

    print("\nAll levels passed validation.")


if __name__ == "__main__":
    main()
